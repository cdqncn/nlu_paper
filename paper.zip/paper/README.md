
## How to run training:
1) python main_joint.py
## Change dataset:
1) Modify data_path in config.py 





