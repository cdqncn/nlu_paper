import os

root_dir = os.path.expanduser("~")
# path
data_path = "./data/atis/"
vocab_path = data_path + "vocab.txt"
model_save_dir = "./ckpt/"
model_path = "best_model.bin"

# model hyperparameters
hidden_dim = 128
emb_dim = 300
emb_dorpout = 0.8
lstm_dropout = 0.5
attention_dropout = 0.1
num_attention_heads = 8

# hyperparameters
weight_decay = 0.000001
max_len = 32
lr_scheduler_gama = 0.5
batch_size= 32
epoch = 90
seed = 9
lr=0.001
use_gpu=True

def show_parameter():
    print("show model parameter : \n")
    print("    hidden_dim: ", hidden_dim)
    print("    emb_dim: ", emb_dim)
    print("    lstm_dropout: ", lstm_dropout)
    print("    attention_dropout: ", attention_dropout)
    print("    num_attention_heads: ", num_attention_heads)
    print("\n")
    print("show train parameter : \n")
    print("    weight_decay: ", weight_decay)
    print("    max_len: ", max_len)
    print("    batch_size: ", batch_size)
    print("    epoch: ", epoch)
    print("    lr: ", lr)
    print("    use_gpu: ", use_gpu)
    print("\n")

